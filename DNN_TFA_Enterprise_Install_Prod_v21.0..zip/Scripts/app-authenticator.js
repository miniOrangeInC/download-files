function ValidateTOTP(url, markTfaConfiguredUrl, method, codeId, configFlow = 'Admin', invokeTfaUrl = '') {
    var code = document.getElementById(codeId).value;
    var formData = new FormData();
    formData.append("authType", "APP");
    formData.append("code", code);
    formData.append("flowType", "registeration");

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: true,
        success: function (response) {
            if (response == "SUCCESS") {
                Mark2FAMethodConfigured(markTfaConfiguredUrl, method, configFlow);
                if (configFlow == 'Admin') {
                    invokeTfaUrl = invokeTfaUrl + '?status=success';
                    location.href = invokeTfaUrl;
                }
                else {
                    document.getElementById('show-success').style.display = 'block';
                    setTimeout(Reload, 1000, configFlow, invokeTfaUrl);
                }
            } else {
                showFloatingAlert('Invalid Code Entered!', 'dangerm', 2000);
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}



function SaveBrandName(url) {
    var brandName = document.getElementById("brand-name").value;

    var formData = new FormData();
    formData.append("brandName", brandName);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            showFloatingAlert('Settings saved successfully!', 'successm', 2000);
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });

}

function configureAppAuth(url, spinnerId, configureAppId, qrCodeId, secretKeyId) {
    document.getElementById(spinnerId).style.display = "block";

    $.ajax({
        type: 'GET',
        url: url,
        async: true,
        success: function (response) {
            document.getElementById(spinnerId).style.display = "none";
            document.getElementById(configureAppId).style.display = "block";
            const authenticatorInfo = response.split(" ");
            document.getElementById(qrCodeId).src = authenticatorInfo[0];
            document.getElementById(secretKeyId).innerHTML = authenticatorInfo[1];
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}
