﻿$(document).ready(function () {
   
    var enableDisableTFA = document.querySelector('.enable-disable-tfa');
    var baseurl = document.getElementById('baseurl') != null ? document.getElementById('baseurl').value : "";
    var isTfaEnabled = document.getElementById('isTFAChecked') != null ? document.getElementById('isTFAChecked').value : "";
    if (isTfaEnabled.toLowerCase() == "true") {
        enableDisableTFA.classList.add('active');
    }
    if (enableDisableTFA != null) {
        enableDisableTFA.addEventListener('click', function () {
            if (!enableDisableTFA.classList.contains('active')) {
                enableDisableTFA.classList.add('active');
                this.checked = true;
                EnableOrDisableTFA(baseurl+'/desktopmodules/tfa/api/tfa/enabledisabletfa', this, 'Users')

            } else {
                enableDisableTFA.classList.remove('active');
                this.checked = false;
                EnableOrDisableTFA(baseurl+'/desktopmodules/tfa/api/tfa/enabledisabletfa', this, 'Users')
            }
        });
    }
});

function SendForEnroll(url) {
    var url = document.getElementById("enroll-url").value;
    window.open(url, "_blank")
}
function ConfigureDuoPush(url) {
    $.ajax({
        type: 'GET',
        url: url,
        async: true,
        success: function (response) {
            var data = JSON.parse(response);
            var sendmsg = document.getElementById("duo-send-message");
            document.getElementById("duo-config").style.display = 'block';
            document.getElementById("duo-message").innerHTML = '';
            sendmsg.innerHTML = '';
            document.getElementById("duo-message").innerHTML = data["message"];
            if (data["status"] == "enroll") {
                document.getElementById("enroll-url").value = data["enrollUrl"];
                document.getElementById("enroll-btn").style.display = 'block';
                document.getElementById("send-push").style.display = 'block';
                sendmsg.innerHTML = 'After successfull enrollment, click on Test Push Notification button.';
            } else if (data["status"] == "account_active") {
                sendmsg.innerHTML = 'You can click the button below to send push notification';
                document.getElementById("enroll-btn").style.display = 'none';
                document.getElementById("send-push").style.display = 'block';
            }
            else if (data["status"] == "error") {
                showFloatingAlert(data["message"], "dangerm", duration = 3000)
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}
function saveDNNLoginMethod(url) {
    var selectedLogin = document.querySelector('input[name="dnn-login"]:checked').value;
    var formData = new FormData();
    formData.append("loginType", selectedLogin);

    $.ajax({
        type: "POST",
        url: url,
        contentType: false,
        data: formData,
        processData: false,
        async: false,
        success: function (response) {
            showFloatingAlert('Login type saved successfully!', 'successm', 2000);
        },
        error: function (error) {
            showFloatingAlert('Error saving login type!', 'dangerm', 2000);
        }
    });

}
function SendPush(url, markTfaConfiguredUrl, method, invokeTfaUrl = '', configFlow = 'Admin') {
    var waitApproval = document.getElementById('wait-approval');
    if (waitApproval) {
        waitApproval.style.display = 'block';
    }
    $.ajax({
        type: 'GET',
        url: url,
        async: true,
        success: function (response) {
            if (waitApproval) {
                waitApproval.style.display = 'none';
            }

            if (response == "SUCCESS") {
                Mark2FAMethodConfigured(markTfaConfiguredUrl, method, configFlow);
                //document.getElementById("show-success").style.display = "block";
                if (configFlow == 'Admin') {
                    invokeTfaUrl = invokeTfaUrl + '?status=success';
                    location.href = invokeTfaUrl;
                }
                else {
                    document.getElementById('show-success').style.display = 'block';
                    setTimeout(Reload, 1000, configFlow, invokeTfaUrl);
                }
            } else {
                if (configFlow == 'Admin') {
                    invokeTfaUrl = invokeTfaUrl + '?status=danger';
                    location.href = invokeTfaUrl;
                }
                else {
                    showFloatingAlert('Request Approval failed!!', 'dangerm', 2000);
                }
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function saveDuoConfig(url, reloadurl) {
    var integrationKey = document.getElementById("integrationKey").value.trim();
    var secretKey = document.getElementById("secretKey").value.trim();
    var api = document.getElementById("api").value.trim();

    if (!integrationKey || !secretKey || !api) {
        showFloatingAlert('Invalid input!!', 'dangerm', 2000);
        return;
    }

    var formData = new FormData();
    formData.append("integrationKey", integrationKey)
    formData.append("secretKey", secretKey)
    formData.append("api", api);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function () {
            reloadurl = reloadurl + '?status=success';
            location.href = reloadurl;
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}
function Mark2FAMethodConfigured(url, method, configFlow) {
    var formData = new FormData();
    formData.append("method", method);
    formData.append("configFlow", configFlow);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            if (response == "FAILED") {
                showFloatingAlert('Failed to save configuration', 'dangerm', 2000);
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function Close(id) {
    document.getElementById(id).style.display = "none";
}

function EnableOrDisableTFAMethod(url, status, method) {
    var currentStatus = "false";
    if (status.checked == true) {
        currentStatus = "true";
    }
    var formData = new FormData();
    formData.append("status", currentStatus);
    formData.append("method", method);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            if (response == "FAILED") {
                showFloatingAlert('Something went wrong', 'dangerm', 2000);
            }
            location.reload();
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function EnableOrDisableTFABackupMethod(url, status, method) {
    var currentStatus = "false";
    if (status.checked == true) {
        currentStatus = "true";
    }
    var formData = new FormData();
    formData.append("status", currentStatus);
    formData.append("method", method);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            location.reload();
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function EnableRoleBasedTFA(url, status, role) {
    var currentStatus = "false";
    if (status.checked == true) {
        currentStatus = "true";
    }
    var formData = new FormData();
    formData.append("status", currentStatus);
    formData.append("role", role);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            location.reload();
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function EnableOrDisableRoleBasedTfa(url, status) {

    var currentStatus = "false";
    if (status.checked == true) {
        currentStatus = "true";
    }
    var formData = new FormData();
    formData.append("status", currentStatus);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            location.reload();
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function ResetTFASettings(url, userId, reloadurl) {
    if (confirm('2FA for the selected user will be reset.')) {
        var formData = new FormData();
        formData.append("userId", userId);

        $.ajax({
            type: 'POST',
            url: url,
            data: formData,
            contentType: false,
            processData: false,
            async: false,
            success: function (response) {
                if (response == "SUCCESS") {
                    reloadurl = reloadurl + '?status=success';
                    location.href = reloadurl;
                } else {
                    showFloatingAlert(response, 'dangerm', 2000);
                }
            },
            error: function (err) {
                showFloatingAlert('Something went wrong', 'dangerm', 2000);
            }
        });
    }
}

function Reload(configFlow, invokeTfaUrl) {
    var showSuccess = document.getElementById("show-success");
    if (showSuccess) {
        showSuccess.style.display = "none";
    }

    if (configFlow == 'EndUser') {
        location.href = invokeTfaUrl;
    }
    else {
        location.reload();
    }
}

function Redirect(redirectUrl) {
    document.getElementById("show-success").style.display = "none";
    location.href = redirectUrl;
}

function sendSupportQuery() {
    var email = document.getElementById("q-email").value;
    var name = document.getElementById("q-name").value;
    var query = document.getElementById("q-message").value;

    var baseurl = document.getElementById("baseurl").value;
    var url = baseurl + "/desktopmodules/tfa/api/tfa/sendsupportquery";

    var formData = new FormData();
    formData.append("email", email);
    formData.append("name", name);
    formData.append("query", query);

    $.ajax({
        url: url,
        type: 'post',
        datatype: 'json',
        data: formData,
        processData: false,
        contentType: false,
        async: false,
        success: function (response) {
            if (response == "SUCCESS") {
                showFloatingAlert('We have received your query and will get back to you soon!', 'successm', 2000);
            } else {
                showFloatingAlert('Something went wrong. Please drop an email directly here dnnsupport@xecurify.com to get the assistance.', 'dangerm', 2000);
            }
            closeContactUsForm();
            window.location.reload();
        },
        error: function (error) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}


function openContactUsForm() {
    var modal = document.getElementById("contact-us");
    modal.style.display = "block";
}

function closeContactUsForm() {
    var modal = document.getElementById("contact-us");
    modal.style.display = "none";
}

function CloseModal() {
    var modal = document.getElementById("show-backup-codes");
    modal.style.display = "none";
}

async function ChangeAccount(url) {
    var result = confirm("Do you really want to change the account?");
    if (!result) {
        return;
    }
    $.ajax({
        type: 'GET',
        url: url,
        async: true,
        success: function () {
            location.reload();
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function EnableOrDisableTFA(url, status, enableOrDisableFor) {
     var currentStatus = "false";
    if (status.checked == true) {
        currentStatus = "true";
       
    }
    
    var formData = new FormData();
    formData.append("status", currentStatus);
    formData.append("enableOrDisableFor", enableOrDisableFor);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function () {
            location.reload();
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function RedirectTo(url) {
    location.href = url;
}

function DownloadBackupCodes() {
    const listItems = document.querySelectorAll('#backup-codes li');
    if (listItems.length === 0) {
        showFloatingAlert('No backup codes available to download.', 'dangerm', 2000);
        return;
    }

    let backupCodes = Array.from(listItems).map(item => item.textContent);
    let blob = new Blob([backupCodes.join('\n')], { type: 'text/plain' });
    let link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = 'Backup_Codes.txt';
    link.click();

}

function ShowBackupCodes() {
    var baseurl = document.getElementById('baseurl').value;
    var list = document.getElementById('backup-codes');
    var backupCodes = GetBackupCodes(baseurl+'/desktopmodules/tfa/api/tfa/GenerateBackupCodes');
    if (!list.hasChildNodes()) {
        backupCodes.forEach((item) => {
            var addElement = document.createElement('li');
            addElement.setAttribute('class', 'badge bg-dark');
            addElement.setAttribute('style', 'font-size: 16px; color:white');
            addElement.innerHTML = item;
            list.appendChild(addElement);
        });
    }
    document.getElementById("show-backup-codes").style.display = "block";
}
function GetBackupCodes(url) {
    let backupCodes = [];
    $.ajax({
        type: 'GET',
        url: url,
        async: false,
        success: function (response) {
            backupCodes = response;
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
    return backupCodes;
}

function ValidateBackupCode(url, loginUrl, authType) {
    var code = document.getElementById("backup-code").value;
    var formData = new FormData();
    formData.append("authType", authType);
    formData.append("code", code);
    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            if (response == "SUCCESS") {
                LoginCustomer(loginUrl);
            } else {
                document.getElementById('backup-code-validation-failed').style.display = 'block';
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function ShowBackupCodeValidation() {
    document.getElementById('code-validation').style.display = 'none';
    document.getElementById('backup-code-validation').style.display = 'block';
}

function saveCustomConfig(url, type, reloadurl) {
    var formData = new FormData();
    formData.append("gatewayType", type);

    if (type == 'Twilio') {
        var accountSid = document.getElementById("accountSid").value;
        var authToken = document.getElementById("authToken").value;
        var smsServiceId = document.getElementById("smsServiceId").value;

        formData.append("accountSid", accountSid);
        formData.append("authToken", authToken);
        formData.append("smsServiceId", smsServiceId);
    }

    else if (type == 'Vonage') {
        var version = document.getElementById("vonageVersionSelect").value;
        var brand = document.getElementById("vonageBrandId").value;
        formData.append("version", version)
        formData.append("brandName", brand);
        
        if (version == 'v1') {
            var apiKey = document.getElementById("vonageApiKey").value;
            var apiSecret = document.getElementById("vonageApiSecret").value;
            formData.append("apiKey", apiKey);
            formData.append("apiSecret", apiSecret);
        }
        else {
            var token = document.getElementById("vonageTokenId").value;
            formData.append("bearerToken", token);
        }
    }

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function () {
            reloadurl = reloadurl + "?status=success";
            location.href = reloadurl;
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function toggleVonageVersion(select) {
    var val = select.value;
    var v1Block = document.getElementById('v1-param');
    var v2Block = document.getElementById('v2-param');
    v1Block.style.display = 'none';
    v2Block.style.display = 'none';
    if (val == 'v1') {
        v1Block.style.display = 'block';
    }
    else {
        v2Block.style.display = 'block';
    }
}

function EnableGateway(url, status, gateway) {
    var currentStatus = "false";
    if (status.checked == true) {
        currentStatus = "true";
    }
    var formData = new FormData();
    formData.append("status", currentStatus);
    formData.append("gateway", gateway);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            if (response == "FAILED") {
                showFloatingAlert('Something went wrong in enabling custom gateway', 'dangerm', 2000);
            }
            location.reload();
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function openTroubleshootModal() {
    var modal = document.getElementById("troubleshoot");
    modal.style.display = "block";
}

function closeTroubleshoot() {
    var modal = document.getElementById("troubleshoot");
    modal.style.display = "none";
}

function EnableTroubleshoot(url, status) {
    var baseurl = document.getElementById("baseurl").value;
    var formData = new FormData();
    formData.append("status", status.checked);

        $.ajax({
            type: 'POST',
            url: url,
            data: formData,
            contentType: false,
            processData: false,
            async: false,
            success: function (response) {
                location.reload();
            },
            error: function (err) {
                showFloatingAlert('Something went wrong!', 'dangerm', 2000);
            }
        });
}
function clearLogs() {
    var baseurl = document.getElementById("baseurl").value;
    var url = baseurl + "/desktopmodules/tfa/api/log/clearlogs";
    $.ajax({
        url: url,
        type: 'post',
        success: function () {
            showFloatingAlert('Logs cleared successfully!', 'successm', 2000);
        },
        error: function (err) {
            showFloatingAlert('Something went wrong!', 'dangerm', 2000);
        }
    });
}

function downloadLogs() {
    var baseurl = document.getElementById("baseurl").value;
    var url = baseurl + "/desktopmodules/tfa/api/log/downloadlogs";
    $.ajax({
        url: url,
        type: 'get',
        success: function (data) {
            const myarr = data.split("<!DOCTYPE html>");
            var filename = 'miniOrangelogs.txt';
            var element = document.createElement('a');
            element.setAttribute('href', 'data:text/xml;charset=utf-8,' + encodeURIComponent(myarr[0]));
            element.setAttribute('download', filename);

            element.style.display = 'none';
            document.body.appendChild(element);

            element.click();

            document.body.removeChild(element);
            if (data == "success") {
            }

            window.location.reload();
            window.location.href = window.location.href;
        }
    });
}

function downloadConfigurations() {
    var baseurl = document.getElementById("baseurl").value;
    var url = baseurl + "/desktopmodules/tfa/api/log/downloadconfigurations";
    $.ajax({
        url: url,
        type: 'get',
        success: function (data) {
            const myarr = data.split("<!DOCTYPE html>");
            var filename = 'configurations.txt';
            var element = document.createElement('a');
            element.setAttribute('href', 'data:text/xml;charset=utf-8,' + encodeURIComponent(myarr[0]));
            element.setAttribute('download', filename);

            element.style.display = 'none';
            document.body.appendChild(element);

            element.click();

            document.body.removeChild(element);
            if (data == "success") {
            }

            window.location.reload();
            window.location.href = window.location.href;
        }
    });
}