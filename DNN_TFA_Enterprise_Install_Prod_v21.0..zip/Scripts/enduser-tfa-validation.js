﻿function hideDefault() {
    document.getElementById("dnn_ctr_EditExtension_AuthenticationEditor_cmdUpdate").style.display = "none";
    document.getElementsByClassName("dnnFormMessage")[0].style.display = "none";
}

function ValidateTOTP(url, authType) {
    var code = document.getElementById("code").value;
    var formData = new FormData();
    formData.append("authType", authType);
    formData.append("code", code);
    formData.append("flowType", "login");

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            let validationResult = JSON.parse(response);
            let status = validationResult.status;
            let redirectURL = validationResult.RedirectURL;

            if (status == "Success") {
                var success = document.getElementById("show-success");
                if (success != null) {
                    success.style.display = "block";
                }
                setTimeout(Redirect, 1000, redirectURL);
            } else {
                document.getElementById('code-validation-failed').style.display = 'block';
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });

}

function ValidateEndOTP(url, authType, txnId, otpType) {
    var otpElement;
    var validationSpan;
    if (otpType === "standard") {
        otpElement = document.getElementById("otp");
        validationSpan = document.getElementById("otp-validation-failed");
    }
    else if (otpType === "backup") {
        otpElement = document.getElementById("emailotp");
        validationSpan = document.getElementById("emailotp-validation-failed");
    }

    if (!otpElement) {
        return;
    }
    var code = otpElement.value;
    var formData = new FormData();
    formData.append("authType", authType);
    formData.append("code", code);
    formData.append("txnId", txnId);
    formData.append("flowType", "login");

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {

            let validationResult = JSON.parse(response);
            let status = validationResult.status;
            let redirectURL = validationResult.RedirectURL;

            if (status == "Success") {
                var success = document.getElementById("show-success");
                if (success != null) {
                    success.style.display = "block";
                }
                setTimeout(Redirect, 1000, redirectURL);
            } else {
                validationSpan.style.display = 'block';
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function ValidateBackupCode(url, authType) {
    var code = document.getElementById("backup-code").value;
    var formData = new FormData();
    formData.append("authType", authType);
    formData.append("code", code);
    formData.append('flowType', 'login');

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            let validationResult = JSON.parse(response);
            let status = validationResult.status;
            let redirectURL = validationResult.RedirectURL;
            if (status == "Success") {
                var success = document.getElementById("show-success");
                if (success != null) {
                    success.style.display = "block";
                }
                setTimeout(Redirect, 1000, redirectURL);
            } else {
                document.getElementById('backup-code-validation-failed').style.display = 'block';
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}

function SaveEmail(url) {
    const email = document.getElementById("emailAddress").value;

    if (!email) {
        showFloatingAlert('Please enter a valid email address', 'dangerm', 2000);
        return;
    }

    const formData = new FormData();
    formData.append("email", email);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            if (response === "SUCCESS") {
                showFloatingAlert('Email updated successfully!', 'successm', 2000);

            } else {
                showFloatingAlert('Failed to update email', 'dangerm', 2000);
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong while saving the email', 'dangerm', 2000);
        }
    });
}


function Redirect(redirectUrl) {

    var success = document.getElementById('show-success');
    if (success) {
        success.style.display = 'none';
    }
    location.href = redirectUrl;
}

function showBackupCodeOption() {
    document.getElementById("backup-code-method").style.display = 'block';
    document.getElementById("show-backup-methods").style.display = 'none';
}

