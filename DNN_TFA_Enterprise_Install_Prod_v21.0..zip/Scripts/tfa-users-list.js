﻿document.addEventListener('DOMContentLoaded', () => {
    var accordionButtons = document.querySelectorAll('.accordion-button');
    var accordionCollapse = document.querySelectorAll('.accordion-collapse');

    accordionButtons.forEach(function (button) {
        button.setAttribute('aria-expanded', 'false');
        button.classList.add('collapsed');
    });

    accordionCollapse.forEach(function (collapse) {
        collapse.classList.remove('show');
    });

    var myCollapse3 = new bootstrap.Collapse(document.getElementById('collapseThree'), {
        toggle: true
    });
});

var fullTableData = window.serializedTableData || [];

function searchTable() {
    var table = document.getElementById("tableBody");
    var input = document.getElementById("searchInput");
    var filter = input.value.toLowerCase();

    fullTableData = window.serializedTableData || [];

    if (filter === "") {
        fullTableData = window.serializedPageData || [];
    }

    var noMatch = true;
    table.innerHTML = '';

    for (var i = 0; i < fullTableData.length; i++) {
        var row = fullTableData[i];
        var email = row.Email.toLowerCase();

        if (email.indexOf(filter) > -1) {
            noMatch = false;
            var tr = document.createElement('tr');
            tr.innerHTML = `<td scope="row">${i + 1}</td>
                            <td>${row.UserId.toString()}</td>
                            <td>${row.Email}</td>
                            <td>${row.IsTfaConfigured.toString()}</td>
                            <td>${row.MethodsConfigured.toString()}</td>
                            <td>
                                <button class="btn" style="color: #fff; font-size: 14px; font-weight: 500; padding: 3px 8px; background-color:#d10000; display: flex;" type="button" onclick="ResetTFASettings('${window.baseurl}/desktopmodules/tfa/api/tfa/resettfa','${row.UserId}', '${window.baseurl}/DesktopModules/AuthenticationServices/miniOrange.DNN.TFA/Pages/TfaUsersList.aspx');" ><i class="fa fa-refresh" style="margin: auto; font-size: 13px;" aria-hidden="true"></i>&nbsp;&nbsp;Reset</button>
                            </td>`;
            table.appendChild(tr);
        }
    }

    var noRecordsMessage = document.getElementById("noRecordsMessage");
    if (noMatch) {
        if (!noRecordsMessage) {
            noRecordsMessage = document.createElement("tr");
            noRecordsMessage.id = "noRecordsMessage";
            noRecordsMessage.classList.add("no-records-message");
            noRecordsMessage.innerHTML = "<td colspan='6' style='text-align: center;'>No records found</td>";
            table.appendChild(noRecordsMessage);
        }
    } else {
        if (noRecordsMessage) {
            noRecordsMessage.remove();
        }
    }
}
