function ValidateOTP(url) {
    var code = document.getElementById("otp").value;
    var txnId = document.getElementById("txnId").value;
    var formData = new FormData();
    formData.append("authType", "EMAIL");
    formData.append("code", code);
    formData.append("txnId", txnId);
    formData.append("flowType", "login")
    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            if (response.status == "Success") {
                var success = document.getElementById("show-success");
                if (success != null) {
                    success.style.display = "block";
                }
                setTimeout(Redirect, 1000, response.RedirectURL);
            } else {
                document.getElementById('otp-validation-failed').style.display = 'block';
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}
function sendOtp(url) {
    $.ajax({
        type: 'GET',
        url: url,
        async: true,
        success: function (response) {
            if (response != "") {
                var res = response.split(" ");
                if (res[0] == "SUCCESS") {
                    document.getElementById("txnId").value = res[1];
                    document.getElementById("email").innerHTML = res[2];
                    document.getElementById("backup-email-method").style.display = 'block';
                    document.getElementById("show-backup-methods").style.display = 'none';
                }
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        }
    });
}
        