﻿//function hideDefault() {
//    document.getElementById("dnn_ctr_EditExtension_AuthenticationEditor_cmdUpdate").style.display = "none";
//    document.getElementsByClassName("dnnFormMessage")[0].style.display = "none";
//}

document.addEventListener('DOMContentLoaded', function () {
    const phoneInputField = document.querySelector('#phoneNumber');
    const emailInputField = document.querySelector('#email');
    const baseurl = document.getElementById("baseurl");
    if (phoneInputField) {
        const phoneErrorElement = document.createElement('div');
        phoneErrorElement.id = 'phnError';
        phoneInputField.insertAdjacentElement('afterend', phoneErrorElement);

        const iti = window.intlTelInput(phoneInputField, {
            initialCountry: 'us',
            utilsScript: baseurl + '/DesktopModules/AuthenticationServices/miniOrange.DNN.TFA/Scripts/Intellipututils18.1.1.js',
            preferredCountries: ['us', 'gb', 'in'],
            separateDialCode: true,
        });

        phoneInputField.addEventListener('input', () => {
            if (iti.isValidNumber()) {
                phoneErrorElement.style.display = 'none';
                phoneInputField.style.borderColor = 'green';
            } else {
                phoneErrorElement.style.display = 'block';
                phoneErrorElement.textContent = '';
                phoneInputField.style.borderColor = 'red';
            }
        });
    }

    if (emailInputField) {
        const emailErrorElement = document.createElement('div');
        emailErrorElement.id = 'emailError';
        emailInputField.insertAdjacentElement('afterend', emailErrorElement);

        emailInputField.addEventListener('input', () => {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (emailRegex.test(emailInputField.value)) {
                emailErrorElement.style.display = 'none'; 
                emailErrorElement.textContent = '';
                emailInputField.style.borderColor = 'green'; 
            } else {
                emailErrorElement.style.display = 'block';
                emailErrorElement.textContent = ''; 
                emailInputField.style.borderColor = 'red'; 
            }
        });
    }
});

function GetOTP(url, authType, phoneOrEmailKey, phoneOrEmailId, codeValidateBlockId, isPasswordLesslogin = "") {
    const inputField = document.getElementById(phoneOrEmailId);
    let value;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const iti = window.intlTelInputGlobals.getInstance(inputField);
    if (authType == "SMS") {
        if (!iti || !iti.isValidNumber()) {
            showFloatingAlert('Invalid phone number. Please correct the number and try again.', 'dangerm');
            return;
        }
        value = iti.getNumber();
    }
    else if (authType == "EMAIL") {
        if (!emailRegex.test(inputField.value)) {
            showFloatingAlert('Invalid email address. Please correct the email and try again.', 'dangerm');
            return;
        }
        value = inputField.value;
    }
    else {
        if (emailRegex.test(inputField.value)) {
            authType = "EMAIL";
            phoneOrEmailKey = "email";
            value = inputField.value;
        }
        else if (validatePhoneNumber(inputField.value)) {
            authType = "SMS";
            phoneOrEmailKey = "phoneNumber";
            value = inputField.value;
        }
        else {
            showFloatingAlert('Invalid Email Address or Phone Number entered!', 'dangerm');
            return;
        }
    }

    const formData = new FormData();
    formData.append('authType', authType);
    formData.append(phoneOrEmailKey, value);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: true,
        success: function (response) {
            const result = response.split(' ');
            if (result[0] === 'SUCCESS') {
                document.getElementById('txnId').value = result[1];
                if (isPasswordLesslogin != 'true') {
                    showFloatingAlert('OTP Sent!', 'successm');
                    if (authType === 'SMS') {
                        toggleConfigButton('phone-close-btn', false);
                    } else {
                        toggleConfigButton('email-close-btn', false);
                    }
                    document.getElementById(codeValidateBlockId).style.display = 'block';
                }
                else {
                    showFloatingAlert('OTP Sent!', 'successm');
                    document.getElementById('otpmethod').value = authType;
                    document.getElementById('phoneoremailid').value = value;
                    document.getElementById("otp-field").style.display = "block";
                    document.getElementById("main-field").style.display = "none";
                }
            }
            else {
                showFloatingAlert(response.substring(result[0].length + 1), 'dangerm');
            }
        },
        error: function (err) {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        },
    });
}

function ValidateOTP(url, savePhoneOrEmailUrl, authType, phoneOrEmailKey, phoneOrEmailId, otpId, configFlow = 'Admin', invokeTfaUrl = '', isPasswordLesslogin = '', loginurl = '') {
    const inputField = document.getElementById(phoneOrEmailId);
    let phoneOrEmailValue = document.getElementById(phoneOrEmailId).value;
    const formData = new FormData();
    if (isPasswordLesslogin == "true") {
        if (document.getElementById("otpmethod").value == "EMAIL")
            authType = "EMAIL";
        else
            authType = "SMS";
    }
    else {
        
        if (authType === 'SMS') {
            const iti = window.intlTelInputGlobals.getInstance(inputField);
            if (!iti || !iti.isValidNumber()) {
                showFloatingAlert('Invalid phone number!', 'dangerm');
                return;
            }

            phoneOrEmailValue = iti.getNumber();
            phoneOrEmailValue = phoneOrEmailValue.replace(/\s+/g, '');
        }
    }

    const code = document.getElementById(otpId).value;
    const txnId = document.getElementById('txnId').value;
    
    formData.append('authType', authType);
    formData.append('code', code);
    formData.append('txnId', txnId);
    formData.append("flowType", "registeration");
    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            if (isPasswordLesslogin != "true") {
                if (response === 'SUCCESS') {
                    SavePhoneOrEmail(savePhoneOrEmailUrl, phoneOrEmailKey, phoneOrEmailValue, configFlow);
                    if (configFlow == 'Admin') {
                        invokeTfaUrl = invokeTfaUrl + '?status=success';
                        location.href = invokeTfaUrl;
                    }
                    else {
                        document.getElementById('show-success').style.display = 'block';
                        setTimeout(Reload, 1000, configFlow, invokeTfaUrl);
                    }
                }
                else {
                    showFloatingAlert('Invalid Code Entered!', 'dangerm', 2000);
                }
            }
            else {
                if (response === 'SUCCESS') {
                    PasswordLessLoginCustomer(loginurl, authType, phoneOrEmailValue);
                }
                else {
                    showFloatingAlert('Invalid Code Entered!', 'dangerm', 2000);
                }
            }
            
        },
        error: function () {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        },
    });
}

function PasswordLessLoginCustomer(url, authType, emailorPhone) {

    const formData = new FormData();
    formData.append('emailorPhone', emailorPhone);
    formData.append('authType', authType);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        async: true,
        processData: false,
        contentType: false,
        success: function (response) {
            document.getElementById("show-success").style.display = "block";
            setTimeout(Redirect, 1000, document.getElementById("baseurl").value);
        },
        error: function (xhr, status, error) {
            var response = JSON.parse(xhr.responseText);
            showFloatingAlert(response.message, 'dangerm');
        }
    });
}


function SavePhoneOrEmail(url, phoneOrEmailKey, phoneOrEmailValue, configFlow) {

    const formData = new FormData();
    formData.append(phoneOrEmailKey, phoneOrEmailValue);
    formData.append('configFlow', configFlow);

    $.ajax({
        type: 'POST',
        url: url,
        data: formData,
        contentType: false,
        processData: false,
        async: false,
        success: function (response) {
            if (response === 'FAILED') {
                showFloatingAlert(response, 'dangerm');
            }
        },
        error: function () {
            showFloatingAlert('Something went wrong', 'dangerm', 2000);
        },
    });
}

function toggleCustomInput(selectElement, inputType) {
    const containerId = inputType === 'phone' ? 'phone-container' : 'email-container';
    const customInputId = inputType === 'phone' ? 'custom-phone-input' : 'custom-email-input';
    const customName = inputType === 'phone' ? 'customPhone' : 'customEmail';
    const placeholderText = 'Enter your custom field';

    const container = document.getElementById(containerId);

    if (selectElement.value === 'Other') {
        let customInput = document.getElementById(customInputId);

        if (!customInput) {
            customInput = document.createElement('input');
            customInput.type = 'text';
            customInput.id = customInputId;
            customInput.name = customName;
            customInput.placeholder = placeholderText;
            customInput.className = selectElement.className;
            container.classList.remove("show-down");
            container.appendChild(customInput);
            selectElement.style.display = 'none';
        }
    } else {
        const customInput = document.getElementById(customInputId);

        if (customInput) {
            customInput.remove();
            selectElement.style.display = 'inline-block';
            container.classList.add("show-down");
        }
    }
}

//function toggleCustomInput(selectElement, inputType) {
//    const containerId = inputType === 'phone' ? 'phone-container' : 'email-container';
//    const customInputId = inputType === 'phone' ? 'custom-phone-input' : 'custom-email-input';
//    const customName = inputType === 'phone' ? 'customPhone' : 'customEmail';
//    const placeholderText = inputType === 'phone' ? 'Enter your custom phone number field' : 'Enter your custom email address field';

//    const container = document.getElementById(containerId);

//    if (selectElement.value === 'Other') {
//        let customInput = document.getElementById(customInputId);

//        if (!customInput) {
//            customInput = document.createElement('input');
//            customInput.type = 'text';
//            customInput.id = customInputId;
//            customInput.name = customName;
//            customInput.placeholder = placeholderText;
//            customInput.style.marginTop = '5px';
//            customInput.style.height = '40px';
//            customInput.className = selectElement.className;

//            container.appendChild(customInput);
//            selectElement.style.display = 'none';
//        }
//    } else {
//        const customInput = document.getElementById(customInputId);

//        if (customInput) {
//            customInput.remove();
//            selectElement.style.display = 'inline-block';
//        }
//    }
//}

function configuredPhoneField(url) {
    const customInput = document.getElementById('custom-phone-input');
    const selectElement = document.getElementById('phone-select');
    const valueToConfigure = customInput
        ? customInput.value.trim()
        : selectElement.value.trim();

    if (valueToConfigure === '') {
        showFloatingAlert('Please enter a valid value before configuring.', 'dangerm');
        return;
    }

    const formData = new FormData();
    formData.append('selected_mobile', valueToConfigure);

    $.ajax({
        url: url,
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            showFloatingAlert(`${valueToConfigure} has been successfully set as the phone number attribute.`, 'successm');

            if (customInput && valueToConfigure !== '') {
                const option = document.createElement('option');
                option.value = valueToConfigure;
                option.text = valueToConfigure;
                option.selected = true;
                selectElement.add(option);

                customInput.remove();
                selectElement.style.display = '';
            }

            const inputPhnNumberField = document.getElementById('phoneNumber');
            if (inputPhnNumberField) {
                inputPhnNumberField.value = response;
            }
        },
        error: function () {
            showFloatingAlert('An error occurred while updating the data. Please try again.', 'dangerm', 2000);
        }
    });
}

function configuredEmailField(url) {
    const customInput = document.getElementById('custom-email-input');
    const selectElement = document.getElementById('email-select');
    const valueToConfigure = customInput
        ? customInput.value.trim()
        : selectElement.value.trim();

    if (valueToConfigure === '') {
        showFloatingAlert('Please enter a valid value before configuring.', 'dangerm');
        return;
    }

    const formData = new FormData();
    formData.append('selected_email', valueToConfigure);

    $.ajax({
        url: url,
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            showFloatingAlert(`${valueToConfigure} has been successfully set as the phone number attribute.`, 'successm');
 
            if (customInput && valueToConfigure !== '') {
                const option = document.createElement('option');
                option.value = valueToConfigure;
                option.text = valueToConfigure;
                option.selected = true;
                selectElement.add(option);


                customInput.remove();
                selectElement.style.display = '';
            }

            const inputEmailField = document.getElementById('emailAddress');
            if (inputEmailField) {
                inputEmailField.value = response;
            
            }
        },
        error: function () {
            showFloatingAlert('An error occurred while updating the email. Please try again.', 'dangerm', 2000);
        }
    });
}


function ConfigurePhoneOrEmail(id) {
    document.getElementById(id).style.display = "block";
}