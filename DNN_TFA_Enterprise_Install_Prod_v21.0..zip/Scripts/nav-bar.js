﻿AllowConfiguration = (methodID) => {
    const content = document.getElementById(methodID);
    content.classList.toggle('open');
}

CloseConfiguration = (methodID) => {
    const content = document.getElementById(methodID);
    content.classList.toggle('open');
}

function toggleConfigButton(buttonId, show) {
    document.getElementById(buttonId).style.display = 'none';
    if (show) {
        document.getElementById(buttonId).style.display = 'block';
    }
}

function copyContentById(id) {
    var inputField = document.getElementById(id);
    inputField.select();
    inputField.setSelectionRange(0, 99999);
    document.execCommand("copy");
    showFloatingAlert('Successfully copied to clipboard', 'successm', 2000);
}

function toggleActiveTab(TabId) {
    var tabs = document.getElementsByName('nav_tabs');
    tabs.forEach(function (tab) {
        tab.classList.remove('active-page');
    });

    var activeTab = document.getElementById(TabId);
    if (activeTab) {
        activeTab.classList.add('active-page');
        localStorage.setItem('activeTab', TabId);
    }
}

function setActiveTabOnLoad() {
    var activeTabId = localStorage.getItem('activeTab');
    if (activeTabId) {
        toggleActiveTab(activeTabId);
    } else {
        toggleActiveTab('authapp-tab');
    }
}

document.addEventListener('DOMContentLoaded', function () {
    setActiveTabOnLoad();
});

function showFloatingAlert(message, type, duration = 3000) {
    let alertBox = document.getElementById("floatingAlert");
    let alertMessage = document.getElementById("fAlertMessage");
    let alertIcon = document.getElementById("fAlertIcon");
    let progressBar = document.getElementById("progressBar");

    alertBox.classList.remove("successm", "dangerm", "warningm", "infom");
    alertBox.classList.add(type);
    alertMessage.innerHTML = message;

    alertIcon.className = "";
    let progressBarColor = '';
    switch (type) {
        case "successm":
            alertIcon.className = "fa fa-check-circle";
            progressBarColor = "#176a02";
            break;
        case "dangerm":
            alertIcon.className = "fa fa-times-circle";
            progressBarColor = "#ce0000";
            break;
        case "warningm":
            alertIcon.className = "fa fa-exclamation-triangle";
            progressBarColor = "#856404";
            break;
        case "infom":
            alertIcon.className = "fa fa-info-circle";
            progressBarColor = "#004085";
            break;
    }

    alertBox.style.display = "block";
    alertBox.style.opacity = "1";

    progressBar.innerHTML = '<span></span>';
    let progressBarSpan = progressBar.querySelector('span');
    progressBarSpan.style.width = "100%";
    progressBar.querySelector('span').style.backgroundColor = progressBarColor;
    let progressInterval = setInterval(() => {
        let currentWidth = parseFloat(progressBarSpan.style.width);
        if (currentWidth > 0) {
            progressBarSpan.style.width = (currentWidth - (100 / duration * 100)) + "%";
        }
    }, 100);

    setTimeout(() => {
        clearInterval(progressInterval);
        alertBox.style.opacity = "0";
        setTimeout(() => {
            alertBox.style.display = "none";
        }, 500);
    }, duration);
}