
document.addEventListener("DOMContentLoaded", function () {

    const phoneInputField = document.querySelector("#phnNumberField");
    const errorElement = document.querySelector("#phnError");
    const sendOTPButton = document.querySelector("#sendOTPOverSMSBtn");

    const emailAddressInputField = document.querySelector("#emailAddressField");
    const errorEmailElement = document.querySelector("#emailError");
    const sendOTPOverEmailButton = document.querySelector("#sendOTPOverEmailBtn");

    const baseurl = document.getElementById("baseurl");
    const emailAddressOrPhoneNumberInputField = document.querySelector("#inputnumberoremail");
    const emailorPhoneErrorElement = document.querySelector("#emailorPhoneError");
    const sendOTPOverEmailOrPhoneBtn = document.querySelector("#sendOTPOverEmailOrPhoneBtn");

    if (sendOTPButton) {
        const iti = window.intlTelInput(phoneInputField, {
            initialCountry: 'us',
            preferredCountries: ['us', 'gb', 'in'],
            separateDialCode: true,
            utilsScript: baseurl + '/DesktopModules/AuthenticationServices/miniOrange.DNN.TFA/Scripts/Intellipututils18.1.1.js'
        });

        phoneInputField.addEventListener("input", () => {
            if (iti.isValidNumber()) {
                toggleInvalidPhoneOrEmail(phoneInputField, errorElement, sendOTPButton, true);
            } else {
                toggleInvalidPhoneOrEmail(phoneInputField, errorElement, sendOTPButton, false);
            }
        });

        sendOTPButton.addEventListener("mouseover", () => {
            if (iti.isValidNumber()) {
                toggleInvalidPhoneOrEmail(phoneInputField, errorElement, sendOTPButton, true);
            } else {
                toggleInvalidPhoneOrEmail(phoneInputField, errorElement, sendOTPButton, false);
            }
        });
    }

    if (emailAddressInputField) {
        emailAddressInputField.addEventListener("input", () => {
            if (isValidEmail(emailAddressInputField.value)) {
                toggleInvalidPhoneOrEmail(emailAddressInputField, errorEmailElement, sendOTPOverEmailButton, true);
            } else {
                toggleInvalidPhoneOrEmail(emailAddressInputField, errorEmailElement, sendOTPOverEmailButton, false);
            }
        });

        sendOTPOverEmailButton.addEventListener("mouseover", () => {
            if (isValidEmail(emailAddressInputField.value)) {
                toggleInvalidPhoneOrEmail(emailAddressInputField, errorEmailElement, sendOTPOverEmailButton, true);
            } else {
                toggleInvalidPhoneOrEmail(emailAddressInputField, errorEmailElement, sendOTPOverEmailButton, false);
            }
        });
    }

    if (emailAddressOrPhoneNumberInputField) {
        emailAddressOrPhoneNumberInputField.addEventListener("input", () => {
            if (isValidEmail(emailAddressOrPhoneNumberInputField.value) || validatePhoneNumber(emailAddressOrPhoneNumberInputField.value)) {
                toggleInvalidPhoneOrEmail(emailAddressOrPhoneNumberInputField, emailorPhoneErrorElement, sendOTPOverEmailOrPhoneBtn, true);
            }
            else {
                toggleInvalidPhoneOrEmail(emailAddressOrPhoneNumberInputField, emailorPhoneErrorElement, sendOTPOverEmailOrPhoneBtn, false);
            }
        });

        sendOTPOverEmailOrPhoneBtn.addEventListener("mouseover", () => {
            if (isValidEmail(emailAddressOrPhoneNumberInputField.value) || validatePhoneNumber(emailAddressOrPhoneNumberInputField.value)) {
                toggleInvalidPhoneOrEmail(emailAddressOrPhoneNumberInputField, emailorPhoneErrorElement, sendOTPOverEmailOrPhoneBtn, true);
            } else {
                toggleInvalidPhoneOrEmail(emailAddressOrPhoneNumberInputField, emailorPhoneErrorElement, sendOTPOverEmailOrPhoneBtn, false);
            }
        });
    }

});

function toggleInvalidPhoneOrEmail(inputField, errorMsg, sendOTPBtn, isValid) {
    if (isValid) {
        errorMsg.style.display = "none";
        inputField.style.border = "2px solid green";
        sendOTPBtn.disabled = false;
        sendOTPBtn.style.opacity = "1";
        sendOTPBtn.style.cursor = "pointer";
    }
    else {
        errorMsg.style.display = "block";
        inputField.style.border = "2px solid red";
        sendOTPBtn.disabled = true;
        sendOTPBtn.style.opacity = "0.5";
        sendOTPBtn.style.cursor = "not-allowed";
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePhoneNumber(input) {
    try {
        const phoneUtil = libphonenumber.PhoneNumberUtil.getInstance();
        const phoneNumber = phoneUtil.parseAndKeepRawInput(input, null);
        return phoneNumber && phoneUtil.isValidNumber(phoneNumber);
    }
    catch (error) {
        return false;
    }
}


function showFloatingAlert(message, type, duration = 3000) {
    let alertBox = document.getElementById("floatingAlert");
    let alertMessage = document.getElementById("fAlertMessage");
    let alertIcon = document.getElementById("fAlertIcon");
    let progressBar = document.getElementById("progressBar");

    alertBox.classList.remove("successm", "dangerm", "warningm", "infom");
    alertBox.classList.add(type);
    alertMessage.innerHTML = message;

    alertIcon.className = "";
    let progressBarColor = '';
    switch (type) {
        case "successm":
            alertIcon.className = "fa fa-check-circle";
            progressBarColor = "#176a02";
            break;
        case "dangerm":
            alertIcon.className = "fa fa-times-circle";
            progressBarColor = "#ce0000";
            break;
        case "warningm":
            alertIcon.className = "fa fa-exclamation-triangle";
            progressBarColor = "#856404";
            break;
        case "infom":
            alertIcon.className = "fa fa-info-circle";
            progressBarColor = "#004085";
            break;
    }

    alertBox.style.display = "block";
    alertBox.style.opacity = "1";

    progressBar.innerHTML = '<span></span>';
    let progressBarSpan = progressBar.querySelector('span');
    progressBarSpan.style.width = "100%";
    progressBar.querySelector('span').style.backgroundColor = progressBarColor;
    let progressInterval = setInterval(() => {
        let currentWidth = parseFloat(progressBarSpan.style.width);
        if (currentWidth > 0) {
            progressBarSpan.style.width = (currentWidth - (100 / duration * 100)) + "%";
        }
    }, 100);

    setTimeout(() => {
        clearInterval(progressInterval);
        alertBox.style.opacity = "0";
        setTimeout(() => {
            alertBox.style.display = "none";
        }, 500);
    }, duration);
}